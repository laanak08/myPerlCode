#!/usr/bin/perl
use strict;
# use warnings;
use Data::Dumper;

##############################################################################################
# Author: Marcelle Bonterre -- 3/22/2013
#
# Run As: vmaxRept.pl inputFile [outputFilename]
# Debug: Search for "`rm *debug*`;"
#       Comment it out.
#       This generates a file *debug* which contains debug log of all "  print $debug ..." lines
#
# Result: After program run, outputFilename is generated in the current directory,
#       or if no outfile was indicated, one will be created as inputFile_out.txt, or inputFile{i}out.txt
#       in the case of files with duplicate names where "i" is some number
#
# Input:
#       -
# Output:
#       - Server_Name (hostname)        Storage_Volume          Source
#               - output into a tab separated values file.
#
############################################################################################

my $filePath = $ARGV[0] or die "No CSV file supplied in command.";

#################################################################################################
# Output filenames - Main scripts output, and exception list if it exists get named here.
#################################################################################################
my $basename;
if($filePath =~ /^([\w]+)/){
$basename = $1; # remove extension from filename
}

my $out_name =  $basename . "_out.txt"; # prepare default output filename

# if present, name the output file whatever the user specified
if($ARGV[1]){ $basename = $ARGV[1]; $out_name = $ARGV[1]; }

my $fileint = 0; # int val to handle duplicate filename

# if current output filename is a duplicate, add int after filename
while(-e $out_name){ $out_name = $basename . "{" . $fileint . "}" . "out.txt"; $fileint = $fileint + 1; }
#################################################################################################
open(my $debug,qw(>),"$out_name.debug");
open(my $import, qw(<), $filePath) or die "Could not load '$filePath' $!\n";


my $doWrite = 1; # used to tell the script whether or not to ignore certain records, ie. will be set to 0 when reading clusters
my $server;
my $source;
my $symDev;
my $size;

my %symDevsSize; # "$symDev" => $size
my %symDevsServers; # "$symDev" => @{[$server...]}
my %serversSymDevs; # "$server" => @{[$symDev...]}
my %serverSource; # "$server" => $source

while (<$import>){
	if( /\w/ ){ # skip blank lines
		chomp $_;
		# get source
		if( /Symmetrix\s+ID\s+:\s+(\d+)/ ){
				$source = $1;
		}
		# get server name
		# if server name is of a cluster,
		# set doWrite = 0;
		if( /Initiator\s+Group\s+Name\s+:\s+([\w|-]+)/ ){
			$server = $1;
		        
		        if( $server =~ /Cluster/ ){ $doWrite = 0; }
		        # detect cases where the server name is like: eCaaS-cert-cpdb1a996-997-998-999
		        # when true, we're reading a cluster, so don't write its info
		        elsif( $server =~ /[-]+/ ){
			        my @lineWithDashes = split("-",$server);
			        my $numItemsInlineWithDashes = scalar @lineWithDashes;
			        if($numItemsInlineWithDashes > 2){ $doWrite = 0; }
			        else{ $doWrite = 1; }
		        }else{ $doWrite = 1; }
		        
		        
			if($server =~ /(-\d\d)$/){
				chop($server);
				chop($server);
				chop($server);
			}
			 
		}
		# get Sym Dev
		# get Sym Dev's Size
		# write symDev/size/source if doWrite = 1;
		if( /([\w]{4})\s+[\w]{3}:/ ){
			$symDev = $1;
	                 
			#get size(GB) and mask-name field
			if( /(\d+)\s+(\w|-|\*)+$/ || /\s(\d+)\s[A-Z|a-z]{3,4}/){
				$size = &convertToGigs($1);
	                         
			}
			unless( $doWrite == 0 ){
			        push(@{$symDevsServers{$symDev}},$server);
			        $symDevsSize{$symDev} = $size;
			
			        push(@{$serversSymDevs{$server}},$symDev);
			        $serverSource{$server} = $source;
			        
			        undef $size;
			        undef $symDev;
			        $doWrite = 1;
			}
		}
	}
}# end while
close($import);

# Converts to GB from MB
sub convertToGigs{
        my $size = $_[0];
        my $sizeInGigs = $size/1024;
        return $sizeInGigs;
}

# Each server has many SymDevs.
# Each symDev has a size
# The size of each server is the sum of the size of all the symDevs it sees
# Each symDev is seen my many servers
# thus, it is necessary to divide the size of each symDev by the number of servers that see it. 
my %debugInfo;
my %serverTotalSizes;
my $servCap;
foreach my $server (keys %serversSymDevs){         
	foreach my $symDev (@{$serversSymDevs{$server}}){
	         
		# get $numServersSharing current symDev
		my $numServersSharing = scalar @{$symDevsServers{$symDev}};	       
		# get symDev Size
		my $size = $symDevsSize{$symDev};
		if(!defined($size)){ print $debug "$symDev has error-producing size.\n\n"};
		# compute symDev contrib to total server size
		my $contrib = $size / $numServersSharing;	         
		$servCap += $contrib;

		$debugInfo{$server}{$symDev} = ["$numServersSharing","$contrib"];
	}
	$serverTotalSizes{$server} = $servCap;
	 
	undef $servCap;
}

# write all results to file
open(my $out,qw(>),"$out_name");
print $out "Server_Name\tStorage_Vol(GB)\tSource\n";
my @serverSizes = sort keys %serverTotalSizes;
foreach my $oneServerName (@serverSizes){
        print $out "$oneServerName\t";
        #print $out "$serverTotalSizes{$oneServerName}\t";
	my $size = sprintf("%.3f",$serverTotalSizes{$oneServerName});
	print $out "$size\t";
        print $out "$serverSource{$oneServerName}\n";
}

#print $debug Dumper(\%debugInfo);

print $debug "Server\tSymDev\tNumServersThatShare\tSize(GB)\n";
my @debugServerList = sort keys %debugInfo;
foreach my $serv (@debugServerList){
	print $debug "$serv";
	foreach my $symDev (keys %{$debugInfo{$serv}}){
		print $debug "\t$symDev";
		print $debug "\t$debugInfo{$serv}{$symDev}[0]";
		print $debug "\t$debugInfo{$serv}{$symDev}[1]\n";
	}
}
close($out);
close($out);
close($debug);
`del *debug*`;
 
