#!/usr/bin/perl
use strict;
use warnings;
use File::Basename;
use Data::Dumper;

#################################################################################################################################
# Author: Marcelle Bonterre -- 7/29/2013
#
# Run As:  inputFile outputFilename_WITHOUT_EXTENSION
#
# Result:
#
# Input:
# Output:
#
# DEBUG file (Optional):
#	- To cause a debug file to be generated, uncomment the #debug; call at the bottom of this script.
#		- This will generate a <NAME>_debug.txt file for each SVC that is being reported.
#
################################################################################################################################
# ChangeLog:
#-----------------------------------------------------------------------------------------------------------------------------
# (xx/yy/2013)
#################################################################################################################################

################################################################################################################################
# Output filenames - Main scripts output, an exception list if it exists get named here.
################################################################################################################################
my $filePath = $ARGV[0] or die "No CSV file supplied in command.";
my $basename = fileparse( $filePath, qr/\.[^.]*/ );
my $out_name;

# if present, name the output file whatever the user specified
( $ARGV[1] ) && ( $basename = $ARGV[1] ) && ( $out_name = $ARGV[1] );

# prepare default exceptionList filename
my $exceptsList = $basename . "_exceptions.txt";

# prepare default output filename
$out_name = $basename . "_out.txt";

my $fileint = 0;    # int val to handle duplicate filename

# if current output filename is a duplicate, add int after filename
while ( -e $out_name ) {
    $out_name = $basename . "{" . $fileint . "}" . "out.txt";
    $fileint  = $fileint + 1;
}

# if current exceptionList filename is a duplicate, add int after filename
while ( -e $exceptsList ) {
    $exceptsList = $basename . "{" . $fileint . "}" . "exceptions.txt";
    $fileint     = $fileint + 1;
}
##################################################################################################################################


# ------- gvars -----------
my ($tier, $source, $cluster, $host, $size);
my (%hosts, %clusters);
my @hostlist;

my $heading_regex = qr/.+?Host\s+Name.+?/;
open( my $import, '<', $filePath ) or die "Could not load '$filePath' $!\n";

LINE: while ( my $line = <$import> ) {
    chomp $line;
    my @fields = split( ",", $line );
    next LINE if($line =~ $heading_regex);
    parseFile( \@fields );
}
close($import);

sub parseFile  {
    my @fields = @{ $_[0] };

    ( $fields[0] =~ /(\w+)-(.+)-\w+/ ) && ( $tier = $1 ) && ( my $source = $2);

    if( $fields[1] =~ /^.+$/ ) { $cluster = $fields[1]; }else{ $cluster = 'Not_Cluster'; }

    $host = uc( $fields[2] );
    $size =  convertToGigs( $fields[3].'GB' );

    $hosts{$host} = {
	'size' => $size,
	'calc_size' => 0, # initialize the calculated size at zero; key to be used later.
	'cluster' => $cluster,
	'source' => $source,
	'tier' => $tier
    };
    push @{ $clusters{$cluster} }, $host;

    undef $tier; undef $source; undef $cluster; undef $host; undef $size;
}

# Accepts size with Units (ie. GB, TB...) as a string
# Converts to GB without Units attached.
sub convertToGigs {
    my $rawSizeStr = $_[0];
    my $sizeInGigsNoUnits;
    ( $rawSizeStr =~ /(.+)TB/ ) && ($sizeInGigsNoUnits = $1 * 1024) ||
    ( $rawSizeStr =~ /(.+)MB/ ) && ($sizeInGigsNoUnits = $1 / 1024) ||
    ( $rawSizeStr =~ /(.+)GB/ ) && ($sizeInGigsNoUnits = $1);
    return $sizeInGigsNoUnits;
}

sub debug {
    my @hostlist = @{ $_[0] };
    open my $debug,qw/>>/, $basename . "_debug.txt" || die " couldn't open debug for writing\n";
    print $debug "host\tsizeOld(SO)\tclusterSize(CS)\tsizeNew(SO/CS)\tcluster\tsource\ttier\n";
    foreach my $host (@hostlist) {
    	my $sizeOld = sprintf "%.3f",$hosts{$host}{'size'};
    	my $sizeNew = sprintf "%.3f",$hosts{$host}{'calc_size'};
    	$cluster = $hosts{$host}{'cluster'};
	my $clusterSize = scalar @{$clusters{$cluster}};
    	$source = $hosts{$host}{'source'};
    	$tier = $hosts{$host}{'tier'};

	print $debug "$host\t$sizeOld\t$clusterSize\t$sizeNew\t$cluster\t$source\t$tier\n";
    }
    close $debug;
}


{ # this block allows reuse of var names by limiting their scope to this enclosed block
    my $cluster;
    foreach my $host (keys %hosts) {
	$cluster = $hosts{$host}{'cluster'};
	if ($cluster eq 'Not_Cluster') {
            ( $hosts{$host}{'calc_size'} = $hosts{$host}{'size'} ) && next;
	}
        $hosts{$host}{'clusterSize'} = scalar @{ $clusters{ $cluster } };
        $hosts{$host}{'calc_size'} = $hosts{$host}{'size'} / $hosts{$host}{'clusterSize'};
    }
}

open( my $out, qw(>), "$out_name" );

@hostlist = sort keys %hosts;
debug(\@hostlist);
print $out "Server_Name\tStorage_Vol(GB)\tSource\tTier\n";
foreach my $host (@hostlist) {
    $tier = $hosts{$host}{'tier'};
    $source = $hosts{$host}{'source'};
    $cluster = $hosts{$host}{'cluster'};
    $size = sprintf "%.3f",$hosts{$host}{'calc_size'};

    print $out "$host\t$size\t$source\t$tier\n";

    undef $tier; undef $source; undef $cluster; undef $host; undef $size;
}
close($out);

